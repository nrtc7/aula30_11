import Foundation

enum Fuel: String {
    case gasoline = "gasolina"
    case alcohol = "alcool"
    case diesel
    
    private func getCarType() -> String {
        switch self {
        case .gasoline, .alcohol:
            return "carro"
        case .diesel:
            return "caminhão"
        }
    }
    
    func fillUp(price: Float) -> String {
        "Seu \(self.getCarType()) foi abastecido com \(price) reais e \(self.rawValue)"
    }
}

//func fillUp(price: Float, type: Fuel) -> String {
//    switch type {
//    case .gasoline, .alcohol:
//        return "Seu carro foi abastecido com \(price) reais e \(type)"
//    case .diesel:
//        return "Seu caminhão foi abastecido com \(price) reais e \(type)"
//    }
//}

if let fuel = Fuel(rawValue: "diesel") {
    print(fuel.fillUp(price: 10))
}

print(Fuel.gasoline.fillUp(price: 10))
